var mojeIme = "Ivan";
var danUNedelji = 7;
var zavrsenaSkola = false;

console.log(mojeIme, danUNedelji, zavrsenaSkola);