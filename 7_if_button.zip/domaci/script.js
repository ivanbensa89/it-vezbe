var boja = prompt("unesite zeljenu boju").toLowerCase();
var dugme = document.getElementById("dugme");

if(boja == "plava") {
    dugme.style.backgroundColor = "blue";
} else if (boja == "crvena") {
    dugme.style.backgroundColor = "red";
} else {
    dugme.style.backgroundColor = "green";
}

var bojaTeksta = prompt("Unesite boju teksta").toLowerCase();

if(bojaTeksta == "plava"){
    dugme.style.color = "blue";
} else if(bojaTeksta == "crvena") {
    dugme.style.color = "red";
}

var visinaDugmeta = prompt("Unesite željenu visinu (visina mora da bude preko 50px!)");


if (visinaDugmeta >= 50) {
    dugme.style.height = visinaDugmeta + "px";
} else {
    alert("visina mora da bude preko 50px!");
}


var sirinaDugmeta = prompt("Unesite željenu širinu (širina mora da bude preko 50px!)");

if(sirinaDugmeta >= 50) {
    dugme.style.width = sirinaDugmeta + "px";
} else {
    alert("širina mora da bude preko 50px!");
}

