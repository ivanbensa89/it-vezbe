document.getElementById("paragraf").style.fontSize = "100px";


function klikRed() {
  document.getElementById("paragraf").style.color = "red";
};