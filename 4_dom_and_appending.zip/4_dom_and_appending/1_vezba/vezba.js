/*var proizvodi = ["hleb", "mleko", "jogurt"];

document.getElementById("proizvodi").innerHTML = "<p><span style='color:red;'>" + proizvodi[0] + "</span></p>";
document.getElementById("proizvodi").innerHTML += "<p><span style='color:blue;'>" + proizvodi[1] + "</span></p>";
document.getElementById("proizvodi").innerHTML += "<p><span style='color:green;'>" + proizvodi[2] + "</span></p>";*/

// vezba crvena plava zelene boja hleb mleko jogurt

var proizvodi = ["hleb", "mleko", "jogurt"];

document.getElementById("proizvodi").innerHTML = "<p style='color: red;'>" + proizvodi[0] + "</p>";
document.getElementById("proizvodi").innerHTML += "<p style='color: blue;'>" + proizvodi[1] + "</p>";
document.getElementById("proizvodi").innerHTML += "<p style='color: green;'>" + proizvodi[2] + "</p>";
