var proizvodi = ["Maticna ploca", "Ram memorija", "SSD"];
console.log(proizvodi[0]);

proizvodi[3] = "HDD";
console.log(proizvodi);

proizvodi.push("GPU", "Floppy", "CD");
console.log(proizvodi);

proizvodi[2] = "Kuciste";
console.log(proizvodi);
